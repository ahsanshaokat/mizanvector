# losses placeholder
