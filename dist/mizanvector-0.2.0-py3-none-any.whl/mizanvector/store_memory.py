# mem store placeholder
